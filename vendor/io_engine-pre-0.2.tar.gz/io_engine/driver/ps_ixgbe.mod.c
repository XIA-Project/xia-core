#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x53eda548, "module_layout" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0xba66affe, "kmalloc_caches" },
	{ 0x340a2012, "pci_bus_read_config_byte" },
	{ 0x5a34a45c, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0x4c4fef19, "kernel_stack" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0xb85f3bbe, "pv_lock_ops" },
	{ 0xa90c928a, "param_ops_int" },
	{ 0x91eb9b4, "round_jiffies" },
	{ 0x7a242093, "dev_set_drvdata" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0xbd100793, "cpu_online_mask" },
	{ 0x3c3e321c, "dma_set_mask" },
	{ 0xfc94ae5c, "napi_complete" },
	{ 0x780b07ac, "pci_disable_device" },
	{ 0xc7a4fbed, "rtnl_lock" },
	{ 0x8394f01b, "pci_disable_msix" },
	{ 0xc3d9727, "netif_carrier_on" },
	{ 0x87a45ee9, "_raw_spin_lock_bh" },
	{ 0xee525c3e, "ethtool_op_get_sg" },
	{ 0xf89843f9, "schedule_work" },
	{ 0xc0a3d105, "find_next_bit" },
	{ 0x13f065fd, "netif_carrier_off" },
	{ 0x88bfa7e, "cancel_work_sync" },
	{ 0x3f635a5c, "__register_chrdev" },
	{ 0xe47651b8, "x86_dma_fallback_dev" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xd8e005d0, "pci_release_regions" },
	{ 0x9e1bdc28, "init_timer_key" },
	{ 0x999e8297, "vfree" },
	{ 0x6db87c90, "pci_bus_write_config_word" },
	{ 0x47c7b0d2, "cpu_number" },
	{ 0x3c2c5af5, "sprintf" },
	{ 0xb2b29fd9, "in_dev_finish_destroy" },
	{ 0xd6759586, "pci_dev_driver" },
	{ 0xe1d68781, "netif_napi_del" },
	{ 0x7d11c268, "jiffies" },
	{ 0x944258d6, "__netdev_alloc_skb" },
	{ 0x1dcdfe18, "netif_rx" },
	{ 0xe174aa7, "__init_waitqueue_head" },
	{ 0x4f8b5ddb, "_copy_to_user" },
	{ 0xeb534922, "pci_set_master" },
	{ 0xe1bc7ede, "del_timer_sync" },
	{ 0xde0bdcff, "memset" },
	{ 0x7633c1e9, "pci_enable_pcie_error_reporting" },
	{ 0xc39fd7b1, "pci_enable_msix" },
	{ 0x48872910, "pci_restore_state" },
	{ 0x4bc0435f, "dev_err" },
	{ 0xf526695f, "current_task" },
	{ 0xea9a8071, "dev_addr_del" },
	{ 0x27e1a049, "printk" },
	{ 0xa57642f4, "ethtool_op_get_link" },
	{ 0x84690eda, "ethtool_op_set_flags" },
	{ 0xfb55c98f, "free_netdev" },
	{ 0x7ec9bfbc, "strncpy" },
	{ 0xb8e2993d, "register_netdev" },
	{ 0xb4390f9a, "mcount" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0x6bf48311, "dev_close" },
	{ 0xce095088, "mod_timer" },
	{ 0xe19ad8ef, "netif_napi_add" },
	{ 0xfda85a7d, "request_threaded_irq" },
	{ 0x3005254b, "device_init_wakeup" },
	{ 0x5ac8d08b, "ethtool_op_get_flags" },
	{ 0xe4041ed3, "dev_kfree_skb_any" },
	{ 0x1211455a, "vm_insert_page" },
	{ 0x4b5119b9, "dev_open" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0x3ff62317, "local_bh_disable" },
	{ 0x896135d7, "netif_device_attach" },
	{ 0xf1ae8b03, "dev_addr_add" },
	{ 0xc46c0288, "kmem_cache_alloc_node_trace" },
	{ 0x36bdbf48, "pci_disable_link_state" },
	{ 0x618911fc, "numa_node" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0xcdb014a2, "netif_device_detach" },
	{ 0x42c8de35, "ioremap_nocache" },
	{ 0x163f2bfe, "pci_bus_read_config_word" },
	{ 0x8532250, "ethtool_op_set_sg" },
	{ 0xff9b2c81, "__napi_schedule" },
	{ 0x6223cafb, "_raw_spin_unlock_bh" },
	{ 0xd28295d7, "pci_cleanup_aer_uncorrect_error_status" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x799aca4, "local_bh_enable" },
	{ 0x65dadc0e, "eth_type_trans" },
	{ 0x7a95413b, "pci_unregister_driver" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0x33e4cbc6, "kmem_cache_alloc_trace" },
	{ 0x6443d74d, "_raw_spin_lock" },
	{ 0xf09c7f68, "__wake_up" },
	{ 0xfce80819, "pci_set_power_state" },
	{ 0x61f9e4ee, "eth_validate_addr" },
	{ 0x66042368, "pci_disable_pcie_error_reporting" },
	{ 0x74cbf459, "dev_set_promiscuity" },
	{ 0x37a0cba, "kfree" },
	{ 0x236c8c64, "memcpy" },
	{ 0x801678, "flush_scheduled_work" },
	{ 0xd7d0f222, "pci_request_regions" },
	{ 0xe75663a, "prepare_to_wait" },
	{ 0xd1329880, "param_array_ops" },
	{ 0x12cad7a2, "pci_disable_msi" },
	{ 0x30beeca6, "dma_supported" },
	{ 0xedc03953, "iounmap" },
	{ 0xce8c6dcd, "pci_prepare_to_sleep" },
	{ 0x27bdd72b, "__pci_register_driver" },
	{ 0x2288378f, "system_state" },
	{ 0xb352177e, "find_first_bit" },
	{ 0xb00ccc33, "finish_wait" },
	{ 0x4cbbd171, "__bitmap_weight" },
	{ 0x89cb3924, "unregister_netdev" },
	{ 0xe8116e08, "__kmalloc_node" },
	{ 0x4121a732, "ethtool_op_get_tso" },
	{ 0xd1653172, "pci_enable_msi_block" },
	{ 0x933382d0, "__netif_schedule" },
	{ 0x6662dec0, "vmalloc_to_page" },
	{ 0xa542d75d, "skb_put" },
	{ 0x20cc8c48, "pci_enable_device" },
	{ 0xc620e919, "pci_wake_from_d3" },
	{ 0x4f6b400b, "_copy_from_user" },
	{ 0x714b9aa0, "__skb_tx_hash" },
	{ 0xe621f01a, "dev_get_drvdata" },
	{ 0x23fd3028, "vmalloc_node" },
	{ 0x6e720ff2, "rtnl_unlock" },
	{ 0x7278cfff, "dma_ops" },
	{ 0x632a5e92, "device_set_wakeup_enable" },
	{ 0xf20dabd8, "free_irq" },
	{ 0xcca87ecc, "pci_save_state" },
	{ 0xe914e41e, "strcpy" },
	{ 0x9277e519, "alloc_etherdev_mqs" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("pci:v00008086d000010B6sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001508sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C6sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C7sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010C8sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000150Bsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010DDsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010ECsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010E1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F4sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010DBsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010F7sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010FCsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000010FBsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000151Csv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "0E890500D94D835D4D96DB7");
